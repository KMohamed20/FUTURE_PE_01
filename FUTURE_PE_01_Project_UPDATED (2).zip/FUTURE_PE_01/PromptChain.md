# 🎯 Prompt Chain – Task 1: AI-Powered YouTube Script & Thumbnail Generator

## Sujet choisi : « 5 outils d’IA qui peuvent remplacer un emploi à temps plein (en 2025) »

### 1️⃣ Génération d’idées de sujets
**Prompt :**  
"Give me 5 trending YouTube video ideas in the AI & Freelance career niche that are likely to go viral in 2025."

**Résultat :**
- Top 5 AI Tools That Can Replace Your 9–5 Job
- Freelancers, Beware: AI That Does Your Job Better
- How I Run a Business With Just AI Tools
- No Team, No Problem: AI That Works For You
- Can AI Really Replace Human Creativity?

🎯 Choix final : **“5 AI Tools That Can Replace a Full-Time Job in 2025”**

---

### 2️⃣ Génération du titre
**Prompt :**  
"Based on the topic, generate 3 SEO-optimized YouTube titles."

**Résultat :**
- "5 outils d’IA qui peuvent remplacer un emploi à temps plein (en 2025)"
- "Ces outils d’IA font le travail de 5 employés"
- "Travailler sans travailler : l’IA prend le relais"

---

### 3️⃣ Script YouTube (voir Script.md)

---

### 4️⃣ Idée de miniature
**Texte de vignette :** "Replaced by AI?"

**Prompt IA pour DALL·E :**  
"A humanoid robot sitting at a modern office desk, with papers flying in the air, a coffee mug, a laptop open to ChatGPT, cinematic lighting, 16:9 aspect ratio — digital art style."

---

### 5️⃣ Outils utilisés :
- ChatGPT (scripting)
- MidJourney / DALL·E (miniature)
- InVideo / Pictory (montage vidéo)
- Canva (mockup)
- Notion (documentation)