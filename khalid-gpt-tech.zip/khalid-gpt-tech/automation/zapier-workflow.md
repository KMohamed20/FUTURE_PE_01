# Zapier Workflow

Automatisations formulaire -> Notion/Sheets/Email