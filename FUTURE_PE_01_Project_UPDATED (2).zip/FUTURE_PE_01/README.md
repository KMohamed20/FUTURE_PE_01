# 🎯 Task 1 – AI-Powered YouTube Generator (Future Interns)

## 📌 Sujet
**5 outils d’IA qui peuvent remplacer un emploi à temps plein (en 2025)**

## 🛠️ Outils
ChatGPT • Pictory • DALL·E • Canva • Notion

## 📂 Fichiers inclus
- `PromptChain.md` – chaîne d'invites complète
- `Script.md` – script vidéo 100% IA (1000+ mots)
- `assets/thumbnail.png` – miniature générée par IA
- `video/video_link.txt` – lien vers la vidéo finale

## 🧠 Ce que j’ai appris
- Chainer des prompts pour automatiser la création de contenu
- Générer des scripts cohérents et engageants avec l’IA
- Créer des visuels et vidéos attractifs sans équipe

## 🔗 Lien vidéo
👉 Voir la vidéo ici : [Regarder sur InVideo](https://ai.invideo.io/watch/b4hn4lfxeQd)